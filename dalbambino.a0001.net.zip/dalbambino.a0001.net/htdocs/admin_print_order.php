<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();
if (!isset($_SESSION['user_id'])) {
    // No queremos que nadie imprima esto si no está logueado
    exit('Acceso denegado.');
}
require_once 'api/db_connect.php'; // Conexión a la BD

// --- 2. Validar y Obtener el ID del Pedido ---
if (!isset($_GET['id'])) {
    exit('ID de pedido no proporcionado.');
}
$order_id = (int)$_GET['id'];
$order = null;
$order_items = [];

// --- 3. [LÓGICA PARA LEER EL PEDIDO] ---
// A. Buscar los datos principales del pedido
$sql_order = "SELECT * FROM tbl_orders WHERE order_id = ?";
$stmt_order = $conn->prepare($sql_order);
$stmt_order->bind_param("i", $order_id);
$stmt_order->execute();
$result_order = $stmt_order->get_result();

if ($result_order->num_rows === 1) {
    $order = $result_order->fetch_assoc();
} else {
    exit('Pedido no encontrado.');
}
$stmt_order->close();

// B. Buscar los items (platos) de ESE pedido
$sql_items = "SELECT oi.*, p.name AS product_name 
              FROM tbl_order_items oi
              JOIN tbl_products p ON oi.product_id = p.product_id
              WHERE oi.order_id = ?";
                
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $order_id);
$stmt_items->execute();
$result_items = $stmt_items->get_result();

if ($result_items->num_rows > 0) {
    while($row = $result_items->fetch_assoc()) {
        $order_items[] = $row;
    }
}
$stmt_items->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comanda Pedido #<?php echo $order['order_id']; ?></title>
    
    <link rel="stylesheet" href="css/print-style.css">
    
    <style>
        /* Estilos de impresión para ocultar botones */
        @media print {
            .no-print {
                display: none !important;
            }
        }
    </style>
</head>
<body onload="window.print();"> <div class="comanda-wrapper">

        <header class="comanda-header">
            <h1>Dal Bambino</h1>
            <p>Comanda de Pedido</p>
        </header>

        <section class="info-section">
            <h2>Detalles del Pedido</h2>
            <div class="info-group">
                <label>Pedido:</label>
                <span>#<?php echo $order['order_id']; ?></span>
            </div>
            <div class="info-group">
                <label>Fecha:</label>
                <span><?php echo date("d/m/Y h:i A", strtotime($order['order_timestamp'])); ?></span>
            </div>
            <div class="info-group">
                <label>Tipo:</label>
                <span><?php echo htmlspecialchars(strtoupper($order['order_type'])); ?></span>
            </div>
        </section>

        <section class="info-section">
            <h2>Cliente</h2>
            <div class="info-group">
                <label>Nombre:</label>
                <span><?php echo htmlspecialchars($order['customer_name']); ?></span>
            </div>
            <div class="info-group">
                <label><?php echo ($order['order_type'] == 'room') ? 'Habitación:' : 'Dirección:'; ?></label>
                <span><?php echo htmlspecialchars($order['customer_address']); ?></span>
            </div>
        </section>

        <section class="items-section">
            <h2>Platos Pedidos</h2>
            <?php foreach ($order_items as $item): ?>
                <div class="item">
                    <span class="item-name">(<?php echo $item['quantity']; ?>) <?php echo htmlspecialchars($item['product_name']); ?></span>
                    <?php if (!empty($item['notes'])): ?>
                        <span class="item-notes">NOTA: <?php echo htmlspecialchars($item['notes']); ?></span>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </section>

        <section class="info-section total">
            <div class="info-group total">
                <label>TOTAL (USD):</label>
                <span>$<?php echo number_format($order['total_usd'], 2); ?></span>
            </div>
        </section>

        <button class="no-print" onclick="window.close();" style="margin-top: 20px;">
            Cerrar Ventana
        </button>

    </div>

</body>
</html>