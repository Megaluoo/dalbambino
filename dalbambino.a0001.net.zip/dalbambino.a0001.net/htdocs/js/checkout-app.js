/* ---
    Lógica de la Aplicación (checkout-app.js)
    Paso 20: Ocultamiento Total de Opciones (Habitación vs Delivery)
--- */

document.addEventListener("DOMContentLoaded", () => {
    
    const cart = JSON.parse(localStorage.getItem('dalBambinoCart')) || [];
    const bcvRate = parseFloat(localStorage.getItem('dalBambinoRate')) || 0; 

    if (cart.length === 0) {
        window.location.href = 'menu.html';
        return;
    }

    populateSummary(cart, bcvRate);
    setupCheckoutMode();
});

async function setupCheckoutMode() {
    // 1. Leer el modo guardado
    const mode = localStorage.getItem('dalBambinoMode');
    
    // Referencias a elementos
    const radioRoom = document.getElementById('type_room');
    const labelRoom = document.querySelector('label[for="type_room"]');
    const radioDelivery = document.getElementById('type_delivery');
    const labelDelivery = document.querySelector('label[for="type_delivery"]');
    
    const fieldRoom = document.getElementById('room-field');
    const fieldDelivery = document.getElementById('delivery-field');
    
    const inputRoom = document.getElementById('customer_address_room');
    const inputDelivery = document.getElementById('customer_address_delivery');
    
    const customerName = document.getElementById('customer_name');
    const customerPhonePrefix = document.getElementById('customer_phone_prefix');
    const customerPhoneNumber = document.getElementById('customer_phone_number');

    // --- CASO A: MODO HABITACIÓN (QR) ---
    if (mode === 'room') {
        console.log("Modo: Habitación (Ocultando Delivery)");
        
        radioRoom.checked = true;
        radioRoom.style.display = 'inline-block';
        labelRoom.style.display = 'inline-block';
        fieldRoom.style.display = 'block';
        inputRoom.required = true;

        radioDelivery.style.display = 'none';
        labelDelivery.style.display = 'none';
        fieldDelivery.style.display = 'none';
        inputDelivery.required = false;
        
        setupFormSubmit(JSON.parse(localStorage.getItem('dalBambinoCart')));
    } 
    
    // --- CASO B: MODO DELIVERY (WEB NORMAL) ---
    else {
        console.log("Modo: Delivery (Ocultando Habitación)");
        
        radioDelivery.checked = true;
        radioDelivery.style.display = 'inline-block';
        labelDelivery.style.display = 'inline-block';
        fieldDelivery.style.display = 'block';
        inputDelivery.required = true;

        radioRoom.style.display = 'none';
        labelRoom.style.display = 'none';
        fieldRoom.style.display = 'none';
        inputRoom.required = false;

        try {
            const response = await fetch('api/get_client_session.php');
            const data = await response.json();

            if (data.is_logged_in) {
                customerName.value = data.client_name || '';
                if (data.address) inputDelivery.value = data.address;
                if (data.phone && data.phone.length === 11) {
                    customerPhonePrefix.value = data.phone.substring(0, 4);
                    customerPhoneNumber.value = data.phone.substring(4);
                }
                setupFormSubmit(JSON.parse(localStorage.getItem('dalBambinoCart')));
            } else {
                alert("Para hacer un pedido de Delivery, necesitas iniciar sesión o registrarte.");
                window.location.href = 'login_cliente.html';
            }
        } catch (error) {
            console.error("Error sesión:", error);
        }
    }
}

function populateSummary(cart, bcvRate) {
    const summaryList = document.getElementById('summary-items');
    summaryList.innerHTML = '';
    let totalUSD = 0; 
    cart.forEach(item => {
        const lineItemTotal = item.priceUSD * item.quantity;
        totalUSD += lineItemTotal;
        const itemHTML = `
            <div class="summary-item">
                <span class="item-name">(${item.quantity}) ${htmlspecialchars(item.name)}</span>
                <span class="item-price">$${lineItemTotal.toFixed(2)}</span>
            </div>
        `;
        summaryList.innerHTML += itemHTML;
    });
    const totalBsElement = document.getElementById('summary-total-bs');
    if (bcvRate && bcvRate > 0) {
        const totalBS = totalUSD * bcvRate;
        totalBsElement.textContent = `Bs. ${totalBS.toFixed(2)}`;
    } else {
        totalBsElement.textContent = 'al cambio a la tasa del BCV';
    }
    document.getElementById('summary-subtotal').textContent = `$${totalUSD.toFixed(2)}`;
    document.getElementById('summary-total-usd').textContent = `$${totalUSD.toFixed(2)}`;
}

function setupFormSubmit(cart) {
    const form = document.getElementById('checkout-form');
    const submitButton = document.getElementById('submit-order-btn');
    const errorMessageDiv = document.getElementById('error-message');

    form.addEventListener('submit', async function(event) {
        event.preventDefault(); 
        submitButton.textContent = 'Enviando...';
        submitButton.disabled = true;
        errorMessageDiv.style.display = 'none';

        const formData = new FormData(form);
        const phonePrefix = formData.get('customer_phone_prefix');
        const phoneNumber = formData.get('customer_phone_number');
        const fullPhoneNumber = phonePrefix + phoneNumber;
        
        let orderType = 'delivery';
        let customerAddress = '';

        const radioRoom = document.getElementById('type_room');
        if (radioRoom.checked && radioRoom.style.display !== 'none') {
            orderType = 'room';
            customerAddress = formData.get('customer_address');
        } else {
            orderType = 'delivery';
            customerAddress = formData.get('customer_address_delivery');
        }

        const totalUSD = cart.reduce((sum, item) => sum + (item.priceUSD * item.quantity), 0);

        const orderData = {
            customer_name: formData.get('customer_name'),
            customer_phone: fullPhoneNumber,
            order_type: orderType,
            customer_address: customerAddress,
            total_usd: totalUSD,
            items: cart
        };

        try {
            const response = await fetch('api/place_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderData)
            });
            const result = await response.json();
            if (result.success) {
                orderData.order_id = result.order_id; 
                localStorage.setItem('dalBambinoLastOrder', JSON.stringify(orderData));
                localStorage.removeItem('dalBambinoCart');
                localStorage.removeItem('dalBambinoRate');
                window.location.href = 'thank_you.html';
            } else {
                throw new Error(result.message || 'Ocurrió un error desconocido.');
            }
        } catch (error) {
            errorMessageDiv.textContent = `Error al enviar el pedido: ${error.message}`;
            errorMessageDiv.style.display = 'block';
            submitButton.textContent = 'Realizar Pedido';
            submitButton.disabled = false;
        }
    });
}

function htmlspecialchars(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, m => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[m]));
}