/* ---
    Lógica de la Aplicación (menu-app.js)
    Versión CORRECTA y ORDENADA
--- */

let cart = [];
let currentProduct = {};
let bcvRate = 0;
let clientData = { is_logged_in: false, client_name: '' };

// 1. DEFINIR FUNCIONES PRIMERO
function htmlspecialchars(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, m => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[m]));
}

function updateAllPrices(rate) {
    document.querySelectorAll(".product-card").forEach(card => {
        const priceUSD = parseFloat(card.querySelector(".price").getAttribute('data-price-usd'));
        const priceBsElement = card.querySelector(".price-bs");
        
        if (priceBsElement && rate && rate > 0) {
            const priceBS = (priceUSD * rate).toFixed(2);
            priceBsElement.textContent = `Bs. ${priceBS}`;
        } else if (priceBsElement) {
            priceBsElement.textContent = 'al cambio a la tasa del BCV';
        }
    });
}

function updateCartTotals() {
    const totalUSD = cart.reduce((sum, item) => sum + (item.priceUSD * item.quantity), 0);
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    document.querySelectorAll('.cart-counter').forEach(c => c.textContent = totalItems);
    
    const totalUsdEl = document.getElementById('total-price-usd');
    if (totalUsdEl) totalUsdEl.textContent = `$${totalUSD.toFixed(2)}`;
    
    const totalBsElement = document.getElementById('total-price-bs');
    if (totalBsElement) {
        if (bcvRate && bcvRate > 0) {
            const totalBS = totalUSD * bcvRate;
            totalBsElement.textContent = `Bs. ${totalBS.toFixed(2)}`;
        } else {
            totalBsElement.textContent = 'al cambio a la tasa del BCV';
        }
    }
}

function setupScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("visible");
                observer.unobserve(entry.target); 
            }
        });
    }, { threshold: 0.1 });
    const cardsToAnimate = document.querySelectorAll(".product-card");
    cardsToAnimate.forEach((card) => { observer.observe(card); });
}

async function checkClientSessionAndSetupNav() {
    const authContainer = document.getElementById('nav-user-container');
    if (!authContainer) return;

    if (localStorage.getItem('dalBambinoMode') === 'room') {
        authContainer.style.display = 'none';
        return; 
    }
    authContainer.style.display = 'flex';

    try {
        const response = await fetch('api/get_client_session.php');
        const sessionData = await response.json();
        
        if (sessionData.is_logged_in) {
            clientData = sessionData;
            const clientName = sessionData.client_name.split(' ')[0];
            
            authContainer.innerHTML = `
                <div class="user-dropdown">
                    <button class="user-btn">Hola, ${htmlspecialchars(clientName)} <i data-feather="chevron-down"></i></button>
                    <div class="user-dropdown-content">
                        <a href="perfil_cliente.html">Mi Perfil</a>
                        <a href="api/logout_client.php" style="color: #c91c00;">Cerrar Sesión</a>
                    </div>
                </div>`;
            feather.replace();
        } else {
            authContainer.innerHTML = `
                <a href="login_cliente.html" class="cta-button nav-cta login-btn">Entrar</a>
                <a href="registro_cliente.html" class="cta-button nav-cta register-btn">Registrarse</a>`;
        }
    } catch (error) { console.error('Error sesión:', error); }
}

async function loadDynamicMenu() {
    const menuWrapper = document.getElementById('menu-wrapper');
    menuWrapper.innerHTML = '<p class="loading-message">Cargando menú...</p>';
    
    try {
        try {
            const rateResponse = await fetch('api/get_bcv_rate.php');
            if (rateResponse.ok) {
                const rateData = await rateResponse.json();
                if (rateData.success) bcvRate = rateData.bcv_rate;
            }
        } catch (e) { bcvRate = 0; }

        const menuResponse = await fetch('api/get_products.php');
        if (!menuResponse.ok) throw new Error('Error menú');
        const menuData = await menuResponse.json();

        menuWrapper.innerHTML = '';
        if (menuData.length === 0) {
            menuWrapper.innerHTML = '<p class="loading-message">No hay platos disponibles.</p>';
            return;
        }

        menuData.forEach(category => {
            if (category.products.length === 0) return;
            const categorySection = document.createElement('section');
            categorySection.className = 'category-section';
            categorySection.id = category.category_name.toLowerCase().replace(/\s+/g, '-');
            categorySection.innerHTML = `<h2 class="category-title">${htmlspecialchars(category.category_name)}</h2>`;
            const scrollContainer = document.createElement('div');
            scrollContainer.className = 'horizontal-scroll-container';

            category.products.forEach(product => {
                const card = document.createElement('div');
                card.className = 'product-card';
                const price = parseFloat(product.price_usd);
                const img = product.image_url ? htmlspecialchars(product.image_url) : 'https://via.placeholder.com/300x200';
                
                card.innerHTML = `
                    <button class="quick-add-btn"><i data-feather="plus"></i></button>
                    <img src="${img}" alt="${htmlspecialchars(product.name)}">
                    <div class="product-content">
                        <h3>${htmlspecialchars(product.name)}</h3>
                        <p class="description">${htmlspecialchars(product.description)}</p>
                        <div class="product-footer">
                            <span class="price" data-price-usd="${price.toFixed(2)}">$${price.toFixed(2)}</span>
                            <span class="price-bs">Bs. ...</span>
                        </div>
                    </div>
                `;
                card.dataset.product = JSON.stringify(product);
                card.addEventListener('click', (e) => {
                    if (e.target.closest('.quick-add-btn')) { e.stopPropagation(); handleQuickAdd(product); }
                    else { openModal(card); }
                });
                scrollContainer.appendChild(card);
            });
            categorySection.appendChild(scrollContainer);
            menuWrapper.appendChild(categorySection);
        });

        updateAllPrices(bcvRate);
        setupScrollAnimations();
        feather.replace(); 
    } catch (error) {
        console.error(error);
        menuWrapper.innerHTML = `<p class="loading-message">Error de carga.</p>`;
    }
}

// Funciones de Interacción (Carrito, Modal, etc.) - Mismas que antes
function goToCheckout() {
    if (cart.length === 0) { alert("Carrito vacío."); return; }
    localStorage.setItem('dalBambinoCart', JSON.stringify(cart));
    localStorage.setItem('dalBambinoRate', bcvRate);
    window.location.href = 'checkout.html';
}
function handleQuickAdd(product) {
    const existing = cart.find(i => i.product_id === product.product_id && i.notes === "");
    if (existing) existing.quantity++;
    else cart.push({ id: Date.now(), product_id: product.product_id, name: product.name, priceUSD: parseFloat(product.price_usd), notes: "", quantity: 1 });
    updateCartUI(); openCart();
}
function handleAddToCart() {
    const notes = document.getElementById('modal-notes').value;
    const existing = cart.find(i => i.product_id === currentProduct.product_id && i.notes === notes);
    if (existing) existing.quantity++;
    else cart.push({ id: Date.now(), product_id: currentProduct.product_id, name: currentProduct.name, priceUSD: currentProduct.priceUSD, notes: notes, quantity: 1 });
    updateCartUI(); closeModal(); openCart();
}
function updateCartUI() {
    const container = document.getElementById('cart-items');
    if(!container) return;
    container.innerHTML = '';
    if (cart.length === 0) { container.innerHTML = '<p class="cart-empty-msg">Tu carrito está vacío.</p>'; } 
    else {
        cart.forEach(item => {
            container.innerHTML += `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <h4>${htmlspecialchars(item.name)}</h4>
                        <span class="item-price">$${(item.priceUSD * item.quantity).toFixed(2)}</span>
                        ${item.notes ? `<p class="item-notes">${htmlspecialchars(item.notes)}</p>` : ''}
                    </div>
                    <div class="cart-item-controls">
                        <button class="btn-qty minus" data-id="${item.id}">-</button>
                        <span class="item-quantity">${item.quantity}</span>
                        <button class="btn-qty plus" data-id="${item.id}">+</button>
                        <button class="btn-remove" data-id="${item.id}">&times;</button>
                    </div>
                </div>`;
        });
    }
    addCartButtonListeners();
    updateCartTotals();
}
function addCartButtonListeners() {
    document.querySelectorAll('.btn-qty.minus').forEach(b => b.addEventListener('click', () => changeCartQuantity(Number(b.dataset.id), -1)));
    document.querySelectorAll('.btn-qty.plus').forEach(b => b.addEventListener('click', () => changeCartQuantity(Number(b.dataset.id), 1)));
    document.querySelectorAll('.btn-remove').forEach(b => b.addEventListener('click', () => removeFromCart(Number(b.dataset.id))));
}
function changeCartQuantity(id, change) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.quantity += change;
    if (item.quantity <= 0) removeFromCart(id); else updateCartUI();
}
function removeFromCart(id) { cart = cart.filter(i => i.id !== id); updateCartUI(); }
function openModal(cardElement) {
    const modalOverlay = document.getElementById('product-modal');
    if (!modalOverlay) return;
    const product = JSON.parse(cardElement.dataset.product);
    const priceBsText = cardElement.querySelector(".price-bs").textContent; 
    currentProduct = { name: product.name, priceUSD: parseFloat(product.price_usd), product_id: product.product_id };
    document.getElementById('modal-title').textContent = product.name;
    document.getElementById('modal-description').textContent = product.description;
    document.getElementById('modal-price').textContent = `$${parseFloat(product.price_usd).toFixed(2)}`;
    document.getElementById('modal-price-bs').textContent = priceBsText;
    const img = product.image_url ? htmlspecialchars(product.image_url) : 'https://via.placeholder.com/300x200';
    document.getElementById('modal-img').src = img;
    document.getElementById('modal-notes').value = ""; 
    modalOverlay.classList.add('visible');
}
function closeModal() { document.getElementById('product-modal').classList.remove('visible'); }
function openCart() { 
    document.getElementById('cart-drawer').classList.add('visible'); 
    document.getElementById('cart-drawer-overlay').classList.add('visible'); 
    document.body.classList.add('cart-open'); 
}
function closeCart() { 
    document.getElementById('cart-drawer').classList.remove('visible'); 
    document.getElementById('cart-drawer-overlay').classList.remove('visible'); 
    document.body.classList.remove('cart-open'); 
}
function setupCartDrawerListeners() {
    const fab = document.getElementById('cart-fab');
    if(fab) fab.addEventListener('click', openCart);
    const closeBtn = document.getElementById('cart-close-btn');
    if(closeBtn) closeBtn.addEventListener('click', closeCart);
    const overlay = document.getElementById('cart-drawer-overlay');
    if(overlay) overlay.addEventListener('click', closeCart);
}
function setupModalListeners() {
    const closeBtn = document.getElementById('modal-close-btn');
    if(closeBtn) closeBtn.addEventListener('click', closeModal);
    const overlay = document.getElementById('product-modal');
    if(overlay) overlay.addEventListener('click', e => { if(e.target.id === 'product-modal') closeModal(); });
    const addBtn = document.getElementById('modal-add-to-cart-btn');
    if(addBtn) addBtn.addEventListener('click', handleAddToCart);
}

// 4. EVENTOS AL CARGAR
document.addEventListener("DOMContentLoaded", () => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('mode') === 'room') localStorage.setItem('dalBambinoMode', 'room');
    else if (!localStorage.getItem('dalBambinoMode')) localStorage.setItem('dalBambinoMode', 'delivery');
    
    if (urlParams.get('status') === 'welcome') {
        alert("¡Registro Exitoso!");
        window.history.replaceState({}, document.title, "menu.html");
    }

    setupCartDrawerListeners();
    setupModalListeners();
    checkClientSessionAndSetupNav();
    loadDynamicMenu(); 
    feather.replace();
});