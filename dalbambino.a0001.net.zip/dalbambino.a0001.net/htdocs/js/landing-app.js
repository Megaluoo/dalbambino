/* ---
    Lógica de la Aplicación (landing-app.js)
    Paso Final: Integración de Sesión de Cliente
--- */

document.addEventListener("DOMContentLoaded", () => {
    loadFeaturedProducts();
    checkClientSessionAndSetupNav(); // ¡NUEVO!
});

// --- NUEVA FUNCIÓN ---
async function checkClientSessionAndSetupNav() {
    try {
        const response = await fetch('api/get_client_session.php');
        const sessionData = await response.json();
        const navContainer = document.querySelector('.navbar-container');
        
        if (sessionData.is_logged_in) {
            // Si está logueado, mostramos el nombre y el botón de logout
            const clientName = sessionData.client_name.split(' ')[0]; // Solo el primer nombre
            navContainer.innerHTML += `
                <div class="nav-user-area">
                    <span>Hola, ${htmlspecialchars(clientName)}</span>
                    <a href="api/logout_client.php" class="cta-button nav-cta logout-btn">Salir</a>
                </div>
            `;
            // NOTE: Necesitamos crear api/logout_client.php
        } else {
            // Si no está logueado, mostramos el botón de login/registro
            navContainer.innerHTML += `
                <a href="login_cliente.html" class="cta-button nav-cta login-btn">Iniciar Sesión</a>
            `;
        }
        
    } catch (error) {
        console.error('Error al verificar sesión:', error);
    }
    
    // El navbar ya existe, solo necesitamos actualizar el contenido
    setupNavStyles(); 
}

// --- ACTUALIZACIÓN DE NAV: Eliminar viejos CTA y añadir el nuevo ---
function setupNavStyles() {
    const navContainer = document.querySelector('.navbar-container');
    // Eliminamos el botón 'Pedir Ahora' que estaba hardcodeado
    const oldCta = navContainer.querySelector('.nav-cta');
    if (oldCta) oldCta.remove();
}


// --- Lógica anterior ---
async function loadFeaturedProducts() {
    const gridContainer = document.getElementById('featured-grid-dynamic');
    if (!gridContainer) {
        console.error("No se encontró el contenedor 'featured-grid-dynamic'.");
        return;
    }
    gridContainer.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">Cargando platos...</p>'; // Mensaje de carga

    try {
        const response = await fetch('api/get_featured_products.php');
        if (!response.ok) throw new Error('No se pudo cargar la lista de platos.');
        const data = await response.json();
        gridContainer.innerHTML = '';

        if (data.success && data.products.length > 0) {
            data.products.forEach(product => {
                const cardHTML = `
                    <div class="featured-card">
                        <img src="${product.image_url ? htmlspecialchars(product.image_url) : 'https://via.placeholder.com/300x300'}" alt="${htmlspecialchars(product.name)}">
                        <h3>${htmlspecialchars(product.name)}</h3>
                    </div>
                `;
                gridContainer.innerHTML += cardHTML;
            });
        } else {
            gridContainer.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">No hay platos destacados en este momento.</p>';
        }

    } catch (error) {
        console.error("Error al cargar platos destacados:", error);
        gridContainer.innerHTML = '<p style="text-align: center; grid-column: 1 / -1;">Error al cargar los platos.</p>';
    }
}

function htmlspecialchars(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, m => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[m]));
}