/* ---
    Lógica de la Aplicación (thank-you-app.js)
    Genera el resumen y el enlace de WhatsApp
--- */

document.addEventListener("DOMContentLoaded", () => {
    
    // --- CONFIGURACIÓN DE WHATSAPP ---
    // Coloca aquí el número del restaurante
    const RESTAURANT_WHATSAPP_NUMBER = '584126722657'; 
    // ---------------------------------

    // Recuperar los datos del pedido guardados en el paso anterior
    const orderDetails = JSON.parse(localStorage.getItem('dalBambinoLastOrder'));
    
    if (!orderDetails) {
        document.getElementById('summary-wrapper').innerHTML = '<p>No hay detalles del pedido para mostrar.</p>';
        return;
    }

    // 1. Rellenar el HTML de la página
    const summaryList = document.getElementById('summary-items');
    const orderIdElement = document.getElementById('order-id');
    const totalElement = document.getElementById('summary-total-usd');
    const wsButton = document.getElementById('whatsapp-button');

    let totalUSD = 0;
    let messageItems = ''; 

    // Mostrar el ID del pedido
    orderIdElement.textContent = `#${orderDetails.order_id}`;

    // Generar lista de platos
    summaryList.innerHTML = '';
    orderDetails.items.forEach(item => {
        const lineItemTotal = item.priceUSD * item.quantity;
        totalUSD += lineItemTotal;
        
        // HTML para la página
        const itemHTML = `
            <div class="summary-item">
                <span class="item-name">(${item.quantity}) ${htmlspecialchars(item.name)}</span>
                <span class="item-price">$${lineItemTotal.toFixed(2)}</span>
            </div>
            ${item.notes ? `<p class="summary-notes">Notas: ${htmlspecialchars(item.notes)}</p>` : ''}
        `;
        summaryList.innerHTML += itemHTML;
        
        // Texto para WhatsApp
        messageItems += `*(${item.quantity}) ${item.name}*${item.notes ? ` (Nota: ${item.notes})` : ''}\n`;
    });

    totalElement.textContent = `$${totalUSD.toFixed(2)}`;

    // 2. Construir el mensaje de WhatsApp
    // Este mensaje sirve tanto para Habitación como para Delivery
    // porque 'customer_address' ya contiene el N° Habitación o la Dirección
    const message = `
¡Hola Dal Bambino! 👋

Acabo de realizar el pedido *#${orderDetails.order_id}*.

*Cliente:* ${orderDetails.customer_name}
*Teléfono:* ${orderDetails.customer_phone}
*Ubicación:* ${orderDetails.customer_address}

*Resumen del Pedido:*
${messageItems}
*TOTAL: $${totalUSD.toFixed(2)}*
`;

    // 3. Crear el enlace y asignarlo al botón
    const whatsappUrl = `https://wa.me/${RESTAURANT_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    wsButton.href = whatsappUrl;

    // 4. Limpiar memoria para que no se duplique el pedido si recarga
    // (Opcional: puedes comentar esto si quieres que persista un rato para pruebas)
    localStorage.removeItem('dalBambinoLastOrder');
    localStorage.removeItem('dalBambinoCart');
    localStorage.removeItem('dalBambinoRate');
});

function htmlspecialchars(str) {
    if (typeof str !== 'string') return '';
    return str.replace(/[&<>"']/g, m => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[m]));
}