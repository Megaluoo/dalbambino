<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}

// --- 2. Incluir la conexión a la BD ---
require_once 'api/db_connect.php';

$error_msg = '';
$success_msg = '';
$category = null; // Variable para guardar los datos de la categoría

// --- 3. [LÓGICA DE GUARDAR] Procesar el formulario si se envió (POST) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_category'])) {
    
    // Recogemos los datos del formulario
    $category_id = (int)$_POST['category_id'];
    $category_name = trim($_POST['category_name']);
    $category_desc = trim($_POST['category_desc']);
    $order_index = (int)$_POST['order_index'];

    if (!empty($category_name) && !empty($category_id)) {
        // Preparamos la consulta SQL para ACTUALIZAR (UPDATE)
        $sql = "UPDATE tbl_categories 
                SET name = ?, description = ?, order_index = ? 
                WHERE category_id = ?";
        
        $stmt = $conn->prepare($sql);
        // 'ssii' = string, string, integer, integer
        $stmt->bind_param("ssii", $category_name, $category_desc, $order_index, $category_id);

        if ($stmt->execute()) {
            // ¡Éxito! Redirigimos de vuelta a la lista
            header('Location: admin_categories.php?status=updated');
            exit();
        } else {
            $error_msg = "Error al actualizar la categoría: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error_msg = "El nombre y el ID de la categoría no pueden estar vacíos.";
    }
}

// --- 4. [LÓGICA DE LEER] Obtener los datos de la categoría para rellenar el formulario (GET) ---
// Verificamos que nos hayan pasado un ID por la URL
if (isset($_GET['id'])) {
    $category_id = (int)$_GET['id'];

    $sql_select = "SELECT * FROM tbl_categories WHERE category_id = ?";
    $stmt = $conn->prepare($sql_select);
    $stmt->bind_param("i", $category_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Encontramos la categoría, guardamos sus datos
        $category = $result->fetch_assoc();
    } else {
        $error_msg = "No se encontró la categoría.";
    }
    $stmt->close();
} else {
    // Si no hay ID en la URL, redirigir
    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        header('Location: admin_categories.php?error=noid');
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Categoría - Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        
        <a href="admin_categories.php" class="back-link">&larr; Volver a Categorías</a>
        
        <h1>Editar Categoría</h1>
        <p>Modifica los detalles de la categoría seleccionada.</p>

        <div class="form-container" style="max-width: 600px; margin: 20px auto;">
            
            <?php if ($category): // Solo mostrar el formulario si encontramos la categoría ?>
                
                <h3>Editando: <?php echo htmlspecialchars($category['name']); ?></h3>
                
                <form action="admin_edit_category.php" method="POST">
                    
                    <input type="hidden" name="category_id" value="<?php echo $category['category_id']; ?>">

                    <?php if (!empty($error_msg)): ?>
                        <div class="message error"><?php echo $error_msg; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="category_name">Nombre de la Categoría (*)</label>
                        <input type="text" id="category_name" name="category_name" 
                               value="<?php echo htmlspecialchars($category['name']); ?>" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="category_desc">Descripción (Opcional)</label>
                        <textarea id="category_desc" name="category_desc" rows="3"><?php echo htmlspecialchars($category['description']); ?></textarea>
                    </div>
                    
                    <div class="input-group">
                        <label for="order_index">Orden (ej: 1, 2, 3...)</label>
                        <input type="number" id="order_index" name="order_index" 
                               value="<?php echo $category['order_index']; ?>">
                    </div>
                    
                    <button type="submit" name="update_category" class="submit-button">Guardar Cambios</button>
                </form>

            <?php else: ?>
                <div class="message error"><?php echo $error_msg; ?></div>
            <?php endif; ?>

        </div>

    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>