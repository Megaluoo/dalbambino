<?php
/*
 * API para LOGIN DE CLIENTES
 * Dal Bambino Ristorante
 */

session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);

    if (empty($phone) || empty($password)) {
        header('Location: ../login_cliente.html?error=emptyfields');
        exit();
    }

    // Buscar cliente por teléfono
    $sql = "SELECT client_id, full_name, password_hash FROM tbl_clients WHERE phone = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $client = $result->fetch_assoc();

        // Verificar contraseña
        if (password_verify($password, $client['password_hash'])) {
            // ¡Éxito!
            session_regenerate_id(true);
            $_SESSION['client_id'] = $client['client_id'];
            $_SESSION['client_name'] = $client['full_name'];

            // Redirigir al menú
            header('Location: ../menu.html');
            exit();
        } else {
            header('Location: ../login_cliente.html?error=wrongpwd');
            exit();
        }
    } else {
        header('Location: ../login_cliente.html?error=nouser');
        exit();
    }
    $stmt->close();
}
$conn->close();
?>