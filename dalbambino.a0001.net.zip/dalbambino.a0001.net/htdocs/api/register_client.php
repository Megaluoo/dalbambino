<?php
/*
 * API para REGISTRO DE CLIENTES
 * Dal Bambino Ristorante
 */

session_start();
require_once 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $password = trim($_POST['password']);
    $address = trim($_POST['default_address']);

    if (empty($full_name) || empty($phone) || empty($password)) {
        header('Location: ../registro_cliente.html?error=emptyfields');
        exit();
    }

    // 1. Verificar si existe
    $sql_check = "SELECT client_id FROM tbl_clients WHERE phone = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("s", $phone);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        header('Location: ../registro_cliente.html?error=userexists');
        exit();
    }
    $stmt_check->close();

    // 2. Encriptar
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // 3. Insertar
    $sql_insert = "INSERT INTO tbl_clients (full_name, phone, password_hash, default_address) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql_insert);
    $stmt->bind_param("ssss", $full_name, $phone, $password_hash, $address);

    if ($stmt->execute()) {
        $_SESSION['client_id'] = $conn->insert_id;
        $_SESSION['client_name'] = $full_name;
        header('Location: ../menu.html?status=welcome');
        exit();
    } else {
        header('Location: ../registro_cliente.html?error=sqlerror');
        exit();
    }
    $stmt->close();
}
$conn->close();
?>