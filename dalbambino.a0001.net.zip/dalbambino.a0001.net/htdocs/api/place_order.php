<?php
/*
 * API para GUARDAR EL PEDIDO (Con soporte para Clientes Registrados)
 */

header('Content-Type: application/json');
require_once 'db_connect.php';
session_start(); // Iniciar sesión para ver si hay cliente logueado

$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data === null || empty($data['items']) || empty($data['customer_name']) || empty($data['customer_phone'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Faltan datos en el pedido.']);
    exit();
}

// --- NUEVO: Verificar si es un cliente registrado ---
$client_id = null; // Por defecto es un invitado (null)
if (isset($_SESSION['client_id'])) {
    $client_id = $_SESSION['client_id'];
}
// ----------------------------------------------------

$conn->begin_transaction();

try {
    // Insertamos el client_id en la tabla (puede ser NULL si es habitación)
    $sql_order = "INSERT INTO tbl_orders (client_id, customer_name, customer_phone, customer_address, order_type, total_usd, status)
                  VALUES (?, ?, ?, ?, ?, ?, 'pending')";
    
    $stmt_order = $conn->prepare($sql_order);
    // 'issssd': integer (o null), string, string, string, string, double
    $stmt_order->bind_param("issssd", 
        $client_id,
        $data['customer_name'],
        $data['customer_phone'],
        $data['customer_address'],
        $data['order_type'],
        $data['total_usd']
    );

    if (!$stmt_order->execute()) {
        throw new Exception('Error al guardar el pedido: ' . $stmt_order->error);
    }

    $new_order_id = $conn->insert_id;
    $stmt_order->close();

    $sql_item = "INSERT INTO tbl_order_items (order_id, product_id, quantity, price_per_item, notes)
                 VALUES (?, ?, ?, ?, ?)";
    $stmt_item = $conn->prepare($sql_item);

    foreach ($data['items'] as $item) {
        $stmt_item->bind_param("iiids",
            $new_order_id,
            $item['product_id'],
            $item['quantity'],
            $item['priceUSD'],
            $item['notes']
        );
        if (!$stmt_item->execute()) {
            throw new Exception('Error al guardar items.');
        }
    }
    $stmt_item->close();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Pedido realizado con éxito', 'order_id' => $new_order_id]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
$conn->close();
?>