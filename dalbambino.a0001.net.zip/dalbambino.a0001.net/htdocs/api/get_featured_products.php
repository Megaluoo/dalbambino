<?php
/*
 * API para OBTENER PLATOS DESTACADOS
 * Dal Bambino Ristorante
 *
 * Devuelve los productos marcados como "is_featured"
 */

header('Content-Type: application/json');
require_once 'db_connect.php';

$menu = [];

try {
    // Buscar solo los productos que son 'is_available' Y 'is_featured'
    // Limitar a 6 para que no se llene la página de inicio
    $sql = "SELECT product_id, name, description, image_url 
            FROM tbl_products 
            WHERE is_available = 1 AND is_featured = 1
            ORDER BY product_id DESC
            LIMIT 6";
            
    $result = $conn->query($sql);

    $products = [];
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
    }
    
    echo json_encode(['success' => true, 'products' => $products]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>