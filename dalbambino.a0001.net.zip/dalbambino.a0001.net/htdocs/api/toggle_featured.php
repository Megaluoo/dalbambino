<?php
/*
 * API para CAMBIAR ESTADO DESTACADO
 * Dal Bambino Ristorante
 */

session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html?error=pleaselogin');
    exit();
}

require_once 'db_connect.php';

if (!isset($_GET['id'])) {
    header('Location: ../admin_products.php?error=noid');
    exit();
}

$product_id = (int)$_GET['id'];

// "Voltear" el valor actual de 'is_featured'
$sql = "UPDATE tbl_products SET is_featured = NOT is_featured WHERE product_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $product_id);

if ($stmt->execute()) {
    header('Location: ../admin_products.php?status=toggled_featured');
} else {
    header('Location: ../admin_products.php?error=togglefailed');
}

$stmt->close();
$conn->close();
?>