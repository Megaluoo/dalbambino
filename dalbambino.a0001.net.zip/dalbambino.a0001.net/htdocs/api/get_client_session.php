<?php
/*
 * API para OBTENER LA SESIÓN DEL CLIENTE (CON DATOS)
 * Dal Bambino Ristorante
 */

session_start();
header('Content-Type: application/json');
require_once 'db_connect.php';

if (isset($_SESSION['client_id'])) {
    
    // Buscamos los datos frescos de la base de datos
    $client_id = $_SESSION['client_id'];
    $sql = "SELECT full_name, phone, default_address, default_room FROM tbl_clients WHERE client_id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'is_logged_in' => true,
            'client_id' => $client_id,
            'client_name' => $row['full_name'],
            'phone' => $row['phone'],
            'address' => $row['default_address'],
            'room' => $row['default_room']
        ]);
    } else {
        // Si no se encuentra (raro), devolvemos sesión cerrada
        echo json_encode(['is_logged_in' => false]);
    }
    $stmt->close();

} else {
    echo json_encode(['is_logged_in' => false]);
}
$conn->close();
?>