<?php
/*
 * Archivo de Lógica de Login (¡VERSIÓN SEGURA!)
 * Dal Bambino Ristorante
 */

session_start();
require_once 'db_connect.php';

// Verificar que los datos fueron enviados
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    header('Location: ../login.html?error=emptyfields');
    exit();
}

$username = trim($_POST['username']);
$password = trim($_POST['password']);

if (empty($username) || empty($password)) {
    header('Location: ../login.html?error=emptyfields');
    exit();
}

// --- 5. Preparar la Consulta a la Base de Datos ---
$sql = "SELECT user_id, username, password_hash, role FROM tbl_users WHERE username = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

// --- 7. Verificar el Resultado ---
if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    // --- ¡¡CAMBIO DE SEGURIDAD IMPORTANTE!! ---
    //
    // ANTES (inseguro):
    // if ($password === $user['password_hash']) {
    //
    // AHORA (seguro):
    // password_verify() compara el texto plano con el hash encriptado
    
    if (password_verify($password, $user['password_hash'])) {

        // ¡CONTRASEÑA CORRECTA!
        
        // Regenerar el ID de sesión por seguridad
        session_regenerate_id(true); 
        
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role']; 

        header('Location: ../admin_dashboard.php');
        exit();

    } else {
        // Contraseña incorrecta
        header('Location: ../login.html?error=wrongpwd');
        exit();
    }
    
} else {
    // Usuario no encontrado
    header('Location: ../login.html?error=nouser');
    exit();
}

$stmt->close();
$conn->close();

?>