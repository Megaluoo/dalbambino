<?php
/*
 * API para OBTENER EL MENÚ COMPLETO
 * Dal Bambino Ristorante
 * * Esto lee la base de datos y la envía como JSON.
 */

// 1. Encabezado JSON: Le decimos al navegador que la respuesta es JSON
header('Content-Type: application/json');

// 2. Incluir la conexión
require_once 'db_connect.php';

// 3. El array final del menú
$menu = [];

try {
    // 4. Obtener todas las CATEGORÍAS (ordenadas)
    $cat_sql = "SELECT * FROM tbl_categories ORDER BY order_index ASC";
    $cat_result = $conn->query($cat_sql);

    if ($cat_result && $cat_result->num_rows > 0) {
        
        // 5. Por cada categoría, buscar sus productos
        while($category = $cat_result->fetch_assoc()) {
            
            $category_id = $category['category_id'];
            
            // Creamos la "entrada" para esta categoría
            $category_entry = [
                'category_name' => $category['name'],
                'products' => [] // Un array vacío para sus platos
            ];

            // 6. Preparamos la consulta para buscar platos DE ESTA CATEGORÍA
            // (Solo traemos los que están marcados como "disponibles" en la BD)
            $prod_sql = "SELECT * FROM tbl_products WHERE category_id = ? AND is_available = 1";
            $stmt = $conn->prepare($prod_sql);
            $stmt->bind_param("i", $category_id);
            $stmt->execute();
            $prod_result = $stmt->get_result();

            if ($prod_result && $prod_result->num_rows > 0) {
                // Añadimos cada plato al array 'products' de la categoría
                while($product = $prod_result->fetch_assoc()) {
                    $category_entry['products'][] = $product;
                }
            }
            
            // 7. AÑADIMOS la categoría (con sus productos) al menú final
            // (Solo si tiene al menos un producto)
            if (count($category_entry['products']) > 0) {
                $menu[] = $category_entry;
            }
        }
    }

    // 8. Imprimir el menú completo como JSON
    echo json_encode($menu);

} catch (Exception $e) {
    // Si algo sale mal, enviar un error
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>