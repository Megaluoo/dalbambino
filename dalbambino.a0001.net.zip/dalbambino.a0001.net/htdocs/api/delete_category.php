<?php
/*
 * Archivo de Lógica para BORRAR Categoría
 * Dal Bambino Ristorante
 */

// 1. Iniciar Sesión y Seguridad
session_start();
if (!isset($_SESSION['user_id'])) {
    // Si no está logueado, no puede borrar
    header('Location: ../login.html?error=pleaselogin');
    exit();
}

// 2. Incluir la conexión a la BD
require_once 'db_connect.php';

// 3. Verificar que recibimos un ID
// (El ID vendrá por la URL, ej: ...delete_category.php?id=3)
if (!isset($_GET['id'])) {
    // Si no hay ID, regresar
    header('Location: ../admin_categories.php?error=noid');
    exit();
}

// 4. Limpiar el ID
$category_id = (int)$_GET['id'];

// 5. Preparar la consulta SQL para BORRAR
// (¡CUIDADO! Esta acción es permanente)
$sql = "DELETE FROM tbl_categories WHERE category_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

// "Atamos" el ID (integer 'i')
$stmt->bind_param("i", $category_id);

// 6. Ejecutar y redirigir
if ($stmt->execute()) {
    // ¡Éxito! Regresamos a la página de categorías con un mensaje
    header('Location: ../admin_categories.php?status=deleted');
} else {
    // Error
    header('Location: ../admin_categories.php?error=deletefailed');
}

$stmt->close();
$conn->close();
?>