<?php
/*
 * API para CAMBIAR DISPONIBILIDAD (Ocultar/Mostrar)
 * Dal Bambino Ristorante
 */

// 1. Iniciar Sesión y Seguridad
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html?error=pleaselogin');
    exit();
}

// 2. Incluir la conexión a la BD
require_once 'db_connect.php';

// 3. Verificar que recibimos un ID
if (!isset($_GET['id'])) {
    header('Location: ../admin_products.php?error=noid');
    exit();
}

$product_id = (int)$_GET['id'];

// 4. Preparar la consulta SQL para ACTUALIZAR
// Usamos "NOT is_available" para "voltear" el valor actual
// Si es 1 (visible), lo vuelve 0 (oculto).
// Si es 0 (oculto), lo vuelve 1 (visible).
$sql = "UPDATE tbl_products SET is_available = NOT is_available WHERE product_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

// "Atamos" el ID (integer 'i')
$stmt->bind_param("i", $product_id);

// 5. Ejecutar y redirigir
if ($stmt->execute()) {
    // ¡Éxito!
    header('Location: ../admin_products.php?status=toggled');
} else {
    // Error
    header('Location: ../admin_products.php?error=togglefailed');
}

$stmt->close();
$conn->close();
?>