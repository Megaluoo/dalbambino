<?php
/*
 * API INTERMEDIARIA PARA OBTENER TASA BCV
 * Dal Bambino Ristorante
 *
 * (Versión 4: "Scraping" directo al bcv.org.ve)
 */

header('Content-Type: application/json');

// 1. URL del BCV
$bcv_url = 'https://www.bcv.org.ve/';

// 2. Inicializar cURL
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => $bcv_url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
    CURLOPT_SSL_VERIFYPEER => false, // Necesario para Byethost
    CURLOPT_SSL_VERIFYHOST => false,
    CURLOPT_FOLLOWLOCATION => true   // Seguir redirecciones si las hay
]);

// 3. Ejecutar la llamada
$html = curl_exec($curl);
$http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
$error = curl_error($curl);
curl_close($curl);

// 4. Manejar la respuesta de cURL
if ($error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de cURL al contactar al BCV: ' . $error]);
    exit();
}

if ($http_code != 200) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'El servidor del BCV respondió con un código de error: ' . $http_code]);
    exit();
}

if (empty($html)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'El BCV devolvió una respuesta vacía.']);
    exit();
}

// 5. ¡El "Scraping"! Usar DOMDocument para leer el HTML
// Suprimimos errores de HTML malformado (común en sitios web)
libxml_use_internal_errors(true);
$dom = new DOMDocument();
$dom->loadHTML($html);
libxml_clear_errors();

// 6. Usar XPath para encontrar el 'div' con id="dolar"
$xpath = new DOMXPath($dom);
// La consulta busca un div con id 'dolar', luego un 'strong' adentro
$query = "//div[@id='dolar']//strong";
$nodes = $xpath->query($query);

if ($nodes === false || $nodes->length == 0) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'No se pudo encontrar el DIV con id="dolar" en la página del BCV. (Posible cambio de diseño)']);
    exit();
}

// 7. Extraer, limpiar y convertir el precio
try {
    // Obtener el primer resultado
    $rate_str_raw = $nodes[0]->nodeValue;
    
    // Limpiar el string (quitar espacios, etc.)
    $rate_str_clean = trim($rate_str_raw);
    
    // Convertir la coma (39,15) a un punto (39.15)
    $rate_str_numeric = str_replace(',', '.', $rate_str_clean);
    
    // Convertir a número (float)
    $bcv_rate_float = (float)$rate_str_numeric;

    if ($bcv_rate_float == 0) {
        throw new Exception('El valor extraído no es un número válido.');
    }

    // 8. ¡ÉXITO!
    echo json_encode([
        'success' => true,
        'bcv_rate' => $bcv_rate_float
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Se encontró el DIV, pero no se pudo procesar el precio. ' . $e->getMessage()]);
}

?>