<?php
/*
 * Archivo de Lógica para BORRAR Plato
 * Dal Bambino Ristorante
 */

// 1. Iniciar Sesión y Seguridad
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html?error=pleaselogin');
    exit();
}

// 2. Incluir la conexión a la BD
require_once 'db_connect.php';

// 3. Verificar que recibimos un ID
if (!isset($_GET['id'])) {
    header('Location: ../admin_products.php?error=noid');
    exit();
}

$product_id = (int)$_GET['id'];

// --- Lógica de borrado de imagen (¡MUY IMPORTANTE!) ---
// Antes de borrar de la BD, buscamos la ruta de la imagen para borrar el archivo.
$sql_find_image = "SELECT image_url FROM tbl_products WHERE product_id = ?";
$stmt_find = $conn->prepare($sql_find_image);
$stmt_find->bind_param("i", $product_id);
$stmt_find->execute();
$result = $stmt_find->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $image_path = $row['image_url'];

    // Si hay una ruta de imagen Y el archivo existe...
    // (Usamos '..' para subir un nivel desde /api/ a /htdocs/)
    if (!empty($image_path) && file_exists('../' . $image_path)) {
        // ...borramos el archivo del servidor.
        unlink('../' . $image_path);
    }
}
$stmt_find->close();
// --- Fin de la lógica de borrado de imagen ---


// 4. Preparar la consulta SQL para BORRAR
$sql_delete = "DELETE FROM tbl_products WHERE product_id = ?";
$stmt_delete = $conn->prepare($sql_delete);

if ($stmt_delete === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

// "Atamos" el ID (integer 'i')
$stmt_delete->bind_param("i", $product_id);

// 5. Ejecutar y redirigir
if ($stmt_delete->execute()) {
    // ¡Éxito!
    header('Location: ../admin_products.php?status=deleted');
} else {
    // Error
    header('Location: ../admin_products.php?error=deletefailed');
}

$stmt_delete->close();
$conn->close();
?>