<?php
/*
 * Archivo de Logout para Clientes
 * Dal Bambino Ristorante
 */

// 1. Iniciar la sesión para poder acceder a ella
session_start();

// 2. Destruir las variables de sesión del cliente
unset($_SESSION['client_id']);
unset($_SESSION['client_name']);

// 3. Redirigir al menú principal
header('Location: ../menu.html');
exit();
?>