<?php
/*
 * Archivo de Conexión a la Base de Datos
 * Dal Bambino Ristorante
 */

// 1. Las "llaves" de tu base de datos
$db_host = 'sql100.byethost33.com';
$db_name = 'b33_40383823_dal_bambino_db';
$db_user = 'b33_40383823';
$db_pass = 'M4T3RN1D4D'; // <-- ¡PON AQUÍ LA NUEVA!

// 2. Crear la conexión usando MySQLi
// (MySQLi es la forma moderna de conectar PHP con MySQL)
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// 3. Verificar la conexión
if ($conn->connect_error) {
    // Si falla, detenemos la ejecución y mostramos el error.
    // 'die()' es una función que detiene el script.
    die("Error de Conexión a la Base de Datos: " . $conn->connect_error);
}

// 4. Asegurar que los acentos y caracteres especiales (ñ) funcionen
// Esto es MUY importante para los nombres de los platos.
$conn->set_charset("utf8mb4");

// Si llegamos aquí, la conexión fue exitosa.
// No necesitamos escribir nada más.
?>