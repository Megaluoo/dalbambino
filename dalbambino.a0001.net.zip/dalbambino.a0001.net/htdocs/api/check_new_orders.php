<?php
/*
 * API para VERIFICAR PEDIDOS NUEVOS
 * Dal Bambino Ristorante
 *
 * Comprueba si hay pedidos 'pendientes' más nuevos
 * que el último ID conocido.
 */

header('Content-Type: application/json');

// 1. Iniciar Sesión (¡Súper importante! No dejamos que nadie vea esto)
session_start();
if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Prohibido
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

// 2. Incluir la conexión
require_once 'db_connect.php';

// 3. Obtener el último ID que el admin ya ha visto (enviado por JS)
// Si no se envía, asumimos 0
$last_order_id = (int)($_GET['last_id'] ?? 0);

// 4. Preparar la consulta
// ¿Hay algún pedido con estado 'pending' Y un ID MAYOR
// al último ID que vimos?
$sql = "SELECT COUNT(order_id) AS new_order_count 
        FROM tbl_orders 
        WHERE status = 'pending' AND order_id > ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $last_order_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$new_order_count = $row['new_order_count'] ?? 0;

$stmt->close();
$conn->close();

// 5. Enviar la respuesta
if ($new_order_count > 0) {
    // ¡SÍ, hay pedidos nuevos!
    echo json_encode(['success' => true, 'new_orders' => true]);
} else {
    // No, no hay nada nuevo.
    echo json_encode(['success' => true, 'new_orders' => false]);
}
?>