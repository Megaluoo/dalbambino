<?php
/*
 * Archivo de Lógica para BORRAR Usuario
 * Dal Bambino Ristorante
 */

// 1. Iniciar Sesión y Seguridad
session_start();

// A. Verificar si está logueado
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html?error=pleaselogin');
    exit();
}

// B. ¡SEGURIDAD CRÍTICA! Verificar si es SUPERADMIN
if ($_SESSION['role'] !== 'superadmin') {
    // Si no es superadmin, no puede borrar.
    header('Location: ../admin_dashboard.php?error=unauthorized');
    exit();
}

// 2. Incluir la conexión a la BD
require_once 'db_connect.php';

// 3. Verificar que recibimos un ID
if (!isset($_GET['id'])) {
    header('Location: ../admin_users.php?error=noid');
    exit();
}

$user_id_to_delete = (int)$_GET['id'];

// 4. Medida de seguridad: NO PERMITIR BORRAR AL USUARIO #1
// (Asumimos que el ID 1 es el superadmin principal)
if ($user_id_to_delete === 1) {
    header('Location: ../admin_users.php?error=cannotdeleteprimary');
    exit();
}

// 5. Preparar la consulta SQL para BORRAR
$sql = "DELETE FROM tbl_users WHERE user_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error al preparar la consulta: " . $conn->error);
}

// "Atamos" el ID (integer 'i')
$stmt->bind_param("i", $user_id_to_delete);

// 6. Ejecutar y redirigir
if ($stmt->execute()) {
    // ¡Éxito!
    header('Location: ../admin_users.php?status=deleted');
} else {
    // Error
    header('Location: ../admin_users.php?error=deletefailed');
}

$stmt->close();
$conn->close();
?>