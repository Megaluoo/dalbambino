<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
require_once 'api/db_connect.php';

$error_msg = '';
$success_msg = '';

// --- LÓGICA DE MENSAJES DE ESTADO (ACTUALIZADO) ---
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'deleted') $success_msg = "¡Plato borrado con éxito!";
    if ($_GET['status'] == 'updated') $success_msg = "¡Plato actualizado con éxito!";
    if ($_GET['status'] == 'toggled') $success_msg = "¡Disponibilidad del plato actualizada!";
    if ($_GET['status'] == 'toggled_featured') $success_msg = "¡Estado de 'Destacado' actualizado!"; // Nuevo
}
if (isset($_GET['error'])) {
    // ... (tus otros mensajes de error) ...
    if ($_GET['error'] == 'togglefailed') $error_msg = "Error al cambiar el estado."; // Nuevo
}

// --- [LÓGICA PARA AÑADIR] (Sin cambios) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    // ... (El código de añadir plato sigue igual) ...
    $category_id = (int)$_POST['category_id'];
    $name = trim($_POST['product_name']);
    $description = trim($_POST['product_desc']);
    $price_usd = (float)$_POST['price_usd'];
    if (empty($name) || empty($price_usd) || empty($category_id)) {
        $error_msg = "Nombre, Precio y Categoría son campos obligatorios.";
    } else {
        $image_url_to_db = null; 
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
            $target_dir = "uploads/";
            $file_extension = pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION);
            $new_filename = uniqid('prod_') . '.' . $file_extension;
            $target_file = $target_dir . $new_filename;
            if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                $image_url_to_db = $target_file;
            } else { $error_msg = "Error al mover el archivo subido."; }
        }
        if (empty($error_msg)) {
            $sql = "INSERT INTO tbl_products (category_id, name, description, price_usd, image_url) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issds", $category_id, $name, $description, $price_usd, $image_url_to_db);
            if ($stmt->execute()) {
                $success_msg = "¡Plato '" . htmlspecialchars($name) . "' añadido con éxito!";
            } else { $error_msg = "Error al guardar: " . $conn->error; }
            $stmt->close();
        }
    }
}

// --- [LÓGICA PARA LEER] (Sin cambios) ---
$categories = [];
$cat_sql = "SELECT * FROM tbl_categories ORDER BY order_index ASC";
$cat_result = $conn->query($cat_sql);
if ($cat_result && $cat_result->num_rows > 0) {
    while($row = $cat_result->fetch_assoc()) { $categories[] = $row; }
}
$products = [];
$prod_sql = "SELECT p.*, c.name AS category_name 
             FROM tbl_products p
             JOIN tbl_categories c ON p.category_id = c.category_id
             ORDER BY p.product_id DESC";
$prod_result = $conn->query($prod_sql);
if ($prod_result && $prod_result->num_rows > 0) {
    while($row = $prod_result->fetch_assoc()) { $products[] = $row; }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Platos - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        <a href="admin_dashboard.php" class="back-link">&larr; Volver al Panel de Control</a>
        <h1>Gestionar Platos</h1>
        <div class="content-grid">
            <div class="form-container">
                <h3>Añadir Nuevo Plato</h3>
                <form action="admin_products.php" method="POST" enctype="multipart/form-data">
                    <?php if (!empty($success_msg)): ?>
                        <div class="message success"><?php echo $success_msg; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($error_msg)): ?>
                        <div class="message error"><?php echo $error_msg; ?></div>
                    <?php endif; ?>
                    <div class="input-group">
                        <label for="category_id">Categoría (*)</label>
                        <select id="category_id" name="category_id" required>
                            <option value="">-- Seleccione una categoría --</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['category_id']; ?>">
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="input-group">
                        <label for="product_name">Nombre del Plato (*)</label>
                        <input type="text" id="product_name" name="product_name" required>
                    </div>
                    <div class="input-group">
                        <label for="product_desc">Descripción (*)</label>
                        <textarea id="product_desc" name="product_desc" rows="4" required></textarea>
                    </div>
                    <div class="input-group">
                        <label for="price_usd">Precio (USD) (*)</label>
                        <input type="number" id="price_usd" name="price_usd" step="0.01" min="0" required>
                    </div>
                    <div class="input-group">
                        <label for="product_image">Imagen del Plato (Opcional)</label>
                        <input type="file" id="product_image" name="product_image" accept="image/jpeg, image/png">
                    </div>
                    <button type="submit" name="add_product" class="submit-button">Añadir Plato</button>
                </form>
            </div>
            
            <div class="list-container">
                <h3>Platos Actuales</h3>
                <div class="search-bar-container">
                    <input type="text" id="product-search-bar" placeholder="Buscar por nombre de plato...">
                </div>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Imagen</th>
                            <th>Nombre</th>
                            <th>Estado (Cliente)</th>
                            <th>Destacado (Inicio)</th> <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody id="products-table-body">
                        <?php if (empty($products)): ?>
                            <tr><td colspan="5">Aún no has añadido ningún plato.</td></tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>
                                        <img src="<?php echo htmlspecialchars($product['image_url'] ?: 'https://via.placeholder.com/100x60'); ?>" alt="img" class="table-image">
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                    <td>
                                        <?php if ($product['is_available'] == 1): ?>
                                            <span class="status-badge status-available">Visible</span>
                                        <?php else: ?>
                                            <span class="status-badge status-hidden">Oculto</span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td>
                                        <?php if ($product['is_featured'] == 1): ?>
                                            <span class="status-badge status-featured">Sí</span>
                                        <?php else: ?>
                                            <span class="status-badge status-hidden">No</span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="admin_edit_product.php?id=<?php echo $product['product_id']; ?>" class="action-btn edit">Editar</a>
                                        
                                        <a href="api/toggle_availability.php?id=<?php echo $product['product_id']; ?>" 
                                           class="action-btn <?php echo ($product['is_available'] == 1) ? 'toggle-off' : 'toggle-on'; ?>">
                                            <?php echo ($product['is_available'] == 1) ? 'Ocultar' : 'Mostrar'; ?>
                                        </a>
                                        
                                        <a href="api/toggle_featured.php?id=<?php echo $product['product_id']; ?>" 
                                           class="action-btn <?php echo ($product['is_featured'] == 1) ? 'toggle-off-feat' : 'toggle-on-feat'; ?>">
                                            <?php echo ($product['is_featured'] == 1) ? 'Quitar' : 'Destacar'; ?>
                                        </a>
                                        
                                        <a href="api/delete_product.php?id=<?php echo $product['product_id']; ?>" 
                                           class="action-btn delete" 
                                           onclick="return confirm('¿Estás seguro de que quieres borrar \'<?php echo htmlspecialchars($product['name']); ?>\'?');">
                                           Borrar
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
    <script>
        feather.replace();
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchBar = document.getElementById('product-search-bar');
            const tableBody = document.getElementById('products-table-body');
            const rows = tableBody.getElementsByTagName('tr');
            searchBar.addEventListener('keyup', () => {
                const searchTerm = searchBar.value.toLowerCase();
                for (let i = 0; i < rows.length; i++) {
                    const row = rows[i];
                    const productNameCell = row.cells[1]; 
                    if (productNameCell) {
                        const productName = productNameCell.textContent.toLowerCase();
                        if (productName.includes(searchTerm)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>