<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
$username = $_SESSION['username'];
$role = $_SESSION['role'];

// --- 2. Incluir la conexión ---
require_once 'api/db_connect.php';

// --- 3. ¡NUEVO! LÓGICA DE ESTADÍSTICAS ---

// A. Pedidos Pendientes Hoy
// (CURDATE() obtiene la fecha de hoy, ej: 2025-11-15)
$sql_pending = "SELECT COUNT(order_id) AS count 
                FROM tbl_orders 
                WHERE status = 'pending' AND DATE(order_timestamp) = CURDATE()";
$result_pending = $conn->query($sql_pending);
$pending_count = $result_pending->fetch_assoc()['count'] ?? 0;

// B. Ingresos Totales del Día (de pedidos completados o pendientes)
$sql_revenue = "SELECT SUM(total_usd) AS total 
                FROM tbl_orders 
                WHERE DATE(order_timestamp) = CURDATE() AND status != 'cancelled'";
$result_revenue = $conn->query($sql_revenue);
$revenue_today = $result_revenue->fetch_assoc()['total'] ?? 0;

// C. Total de Pedidos en el Mes (para ver el volumen)
$sql_month = "SELECT COUNT(order_id) AS count 
              FROM tbl_orders 
              WHERE order_timestamp >= NOW() - INTERVAL 1 MONTH";
$result_month = $conn->query($sql_month);
$month_count = $result_month->fetch_assoc()['count'] ?? 0;

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Dal Bambino</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($username); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        <h1>Panel de Control</h1>
        <p>Bienvenido. Aquí tienes un resumen de la actividad de hoy.</p>

        <div class="stat-grid">
            
            <div class="stat-card">
                <div class="stat-icon pending">
                    <i data-feather="clock"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?php echo $pending_count; ?></span>
                    <span class="stat-label">Pedidos Pendientes Hoy</span>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon revenue">
                    <i data-feather="dollar-sign"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value">$<?php echo number_format($revenue_today, 2); ?></span>
                    <span class="stat-label">Ingresos del Día</span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon total">
                    <i data-feather="shopping-cart"></i>
                </div>
                <div class="stat-info">
                    <span class="stat-value"><?php echo $month_count; ?></span>
                    <span class="stat-label">Pedidos (Últ. 30 días)</span>
                </div>
            </div>

        </div>
        <h2 class="section-title">Herramientas de Gestión</h2>
        <div class="admin-grid">

            <a href="admin_products.php" class="admin-card">
                <i data-feather="coffee"></i>
                <h3>Gestionar Platos</h3>
                <p>Añadir, editar o eliminar platos del menú.</p>
            </a>
            
            <a href="admin_categories.php" class="admin-card">
                <i data-feather="tag"></i>
                <h3>Gestionar Categorías</h3>
                <p>Crear o editar las secciones (Entradas, Pastas, etc.).</p>
            </a>

            <a href="admin_orders.php" class="admin-card">
                <i data-feather="shopping-cart"></i>
                <h3>Ver Pedidos</h3>
                <p>Revisar los pedidos pendientes y completados.</p>
            </a>

            <?php if ($role === 'superadmin'): ?>
                <a href="admin_users.php" class="admin-card superadmin-card">
                    <i data-feather="users"></i>
                    <h3>Gestionar Usuarios</h3>
                    <p>Crear o editar las cuentas de administrador.</p>
                </a>
            <?php endif; ?>

        </div>
    </main>

    <script>
        feather.replace(); // Activa los iconos
    </script>
</body>
</html>