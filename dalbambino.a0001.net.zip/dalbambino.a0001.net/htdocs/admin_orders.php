<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
require_once 'api/db_connect.php';

// --- 1. CONTADORES DE PEDIDOS PENDIENTES ---
$sql_c_room = "SELECT COUNT(*) as count FROM tbl_orders WHERE status='pending' AND order_type='room'";
$res_c_room = $conn->query($sql_c_room);
$count_room = $res_c_room->fetch_assoc()['count'];

$sql_c_del = "SELECT COUNT(*) as count FROM tbl_orders WHERE status='pending' AND order_type='delivery'";
$res_c_del = $conn->query($sql_c_del);
$count_delivery = $res_c_del->fetch_assoc()['count'];

$total_pending = $count_room + $count_delivery;
// -------------------------------------------

// --- LÓGICA DE FILTRADO ---
$time_filter = $_GET['time_filter'] ?? 'today'; 
$type_filter = $_GET['type_filter'] ?? 'all';

$sql_base = "SELECT * FROM tbl_orders";
$conditions = [];

// A. Tiempo
switch ($time_filter) {
    case 'today': $conditions[] = "(DATE(order_timestamp) = CURDATE() OR status = 'pending')"; break;
    case 'week': $conditions[] = "(order_timestamp >= NOW() - INTERVAL 7 DAY OR status = 'pending')"; break;
    case 'month': $conditions[] = "(order_timestamp >= NOW() - INTERVAL 1 MONTH OR status = 'pending')"; break;
    case 'all_time': break;
}

// B. Tipo
if ($type_filter == 'room') { $conditions[] = "order_type = 'room'"; } 
elseif ($type_filter == 'delivery') { $conditions[] = "order_type = 'delivery'"; }

$sql_where = "";
if (count($conditions) > 0) {
    $sql_where = " WHERE " . implode(" AND ", $conditions);
}

$sql_select = $sql_base . $sql_where . " ORDER BY order_timestamp DESC";

$orders = [];
$result = $conn->query($sql_select);
$latest_order_id_on_page = 0; 

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
    $latest_order_id_on_page = $orders[0]['order_id'];
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Pedidos - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>
    <audio id="notification-sound" src="notification.mp3" preload="auto"></audio>
    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>
    <main class="admin-container">
        <div class="top-bar">
            <a href="admin_dashboard.php" class="back-link">&larr; Volver al Panel</a>
            <h1>Gestión de Pedidos</h1>
        </div>
        <?php if ($total_pending > 0): ?>
            <div class="pending-alert pulse-animation">
                <i data-feather="bell"></i>
                <span>Tienes <strong><?php echo $total_pending; ?></strong> pedidos pendientes.</span>
            </div>
        <?php endif; ?>
        <div class="orders-dashboard-grid">
            <a href="admin_orders.php?type_filter=room" class="order-widget room <?php echo ($type_filter == 'room') ? 'active' : ''; ?>">
                <div class="widget-icon"><i data-feather="home"></i></div>
                <div class="widget-info">
                    <h3>Habitación</h3>
                    <span class="widget-count"><?php echo $count_room; ?> Pendientes</span>
                </div>
            </a>
            <a href="admin_orders.php?type_filter=delivery" class="order-widget delivery <?php echo ($type_filter == 'delivery') ? 'active' : ''; ?>">
                <div class="widget-icon"><i data-feather="truck"></i></div>
                <div class="widget-info">
                    <h3>Delivery</h3>
                    <span class="widget-count"><?php echo $count_delivery; ?> Pendientes</span>
                </div>
            </a>
             <a href="admin_orders.php?type_filter=all" class="order-widget all <?php echo ($type_filter == 'all') ? 'active' : ''; ?>">
                <div class="widget-icon"><i data-feather="list"></i></div>
                <div class="widget-info">
                    <h3>Ver Todos</h3>
                    <span class="widget-count">Historial Completo</span>
                </div>
            </a>
        </div>
        <div class="list-container">
            <div class="filter-bar-simple">
                <form action="admin_orders.php" method="GET">
                    <input type="hidden" name="type_filter" value="<?php echo htmlspecialchars($type_filter); ?>">
                    <label>Filtrar por fecha:</label>
                    <select name="time_filter" onchange="this.form.submit()">
                        <option value="today" <?php if ($time_filter == 'today') echo 'selected'; ?>>Hoy + Pendientes</option>
                        <option value="week" <?php if ($time_filter == 'week') echo 'selected'; ?>>Últimos 7 Días</option>
                        <option value="month" <?php if ($time_filter == 'month') echo 'selected'; ?>>Último Mes</option>
                        <option value="all_time" <?php if ($time_filter == 'all_time') echo 'selected'; ?>>Todo</option>
                    </select>
                </form>
            </div>
            <h3>Listado de Pedidos</h3>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Hora</th>
                        <th>Cliente</th>
                        <th>Teléfono</th>
                        <th>Ubicación</th>
                        <th>Tipo</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 30px;">No hay pedidos para mostrar con estos filtros.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                            <tr class="<?php echo ($order['status'] == 'pending') ? 'row-pending' : ''; ?>">
                                <td><strong>#<?php echo $order['order_id']; ?></strong></td>
                                <td><?php echo date("d/m h:i A", strtotime($order['order_timestamp'])); ?></td>
                                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['customer_phone']); ?></td>
                                <td>
                                    <?php 
                                        if($order['order_type'] == 'room') {
                                            echo "<strong>Hab: " . htmlspecialchars($order['customer_address']) . "</strong>";
                                        } else {
                                            echo substr(htmlspecialchars($order['customer_address']), 0, 15) . '...';
                                        }
                                    ?>
                                </td>
                                <td>
                                    <?php if($order['order_type'] == 'room'): ?>
                                        <span class="icon-badge room" title="Habitación"><i data-feather="home"></i></span>
                                    <?php else: ?>
                                        <span class="icon-badge delivery" title="Delivery"><i data-feather="truck"></i></span>
                                    <?php endif; ?>
                                </td>
                                <td>$<?php echo number_format($order['total_usd'], 2); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo htmlspecialchars($order['status']); ?>">
                                        <?php echo htmlspecialchars($order['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="admin_order_detail.php?id=<?php echo $order['order_id']; ?>" 
                                       class="action-btn edit">Ver</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>
        feather.replace();
        const lastKnownOrderId = <?php echo $latest_order_id_on_page; ?>;
        const totalPendingCount = <?php echo $total_pending; ?>;
        const notificationSound = document.getElementById('notification-sound');
        function updatePageTitle(count) {
            if (count > 0) { document.title = `(${count}) Ver Pedidos - Admin`; } 
            else { document.title = `Ver Pedidos - Admin`; }
        }
        updatePageTitle(totalPendingCount);
        async function checkForNewOrders() {
            try {
                const response = await fetch(`api/check_new_orders.php?last_id=${lastKnownOrderId}`);
                const data = await response.json();
                if (data.success && data.new_orders === true) {
                    if (notificationSound) notificationSound.play().catch(e=>{});
                    window.location.reload();
                }
            } catch (error) {}
        }
        setInterval(checkForNewOrders, 10000);
    </script>
</body>
</html>