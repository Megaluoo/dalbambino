<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
require_once 'api/db_connect.php';

$error_msg = '';
$success_msg = '';
$product = null; // Para guardar los datos del plato
$categories = []; // Para guardar las categorías

// --- 2. [LÓGICA DE GUARDAR] Procesar el formulario (POST) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    
    // Recoger datos
    $product_id = (int)$_POST['product_id'];
    $category_id = (int)$_POST['category_id'];
    $name = trim($_POST['product_name']);
    $description = trim($_POST['product_desc']);
    $price_usd = (float)$_POST['price_usd'];
    $old_image_path = $_POST['old_image_path']; 
    $image_url_to_db = $old_image_path; 

    if (empty($name) || empty($price_usd) || empty($category_id) || empty($product_id)) {
        $error_msg = "Error: Faltan datos obligatorios.";
    } else {
        
        // --- Lógica de Imagen (Actualizar) ---
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
            
            $target_dir = "uploads/";
            $file_extension = pathinfo($_FILES["product_image"]["name"], PATHINFO_EXTENSION);
            $new_filename = uniqid('prod_') . '.' . $file_extension;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $target_file)) {
                $image_url_to_db = $target_file;
                
                if (!empty($old_image_path) && file_exists($old_image_path)) {
                    unlink($old_image_path);
                }
            } else {
                $error_msg = "Error al subir la nueva imagen.";
            }
        }

        // --- Actualizar la Base de Datos ---
        if (empty($error_msg)) {
            $sql = "UPDATE tbl_products SET 
                        category_id = ?, 
                        name = ?, 
                        description = ?, 
                        price_usd = ?, 
                        image_url = ? 
                    WHERE product_id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issdsi", $category_id, $name, $description, $price_usd, $image_url_to_db, $product_id);

            if ($stmt->execute()) {
                header('Location: admin_products.php?status=updated');
                exit();
            } else {
                $error_msg = "Error al actualizar la base de datos: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// --- 3. [LÓGICA DE LEER] Obtener datos para rellenar el formulario (GET) ---
if (isset($_GET['id'])) {
    $product_id = (int)$_GET['id'];

    $sql_product = "SELECT * FROM tbl_products WHERE product_id = ?";
    $stmt_product = $conn->prepare($sql_product);
    $stmt_product->bind_param("i", $product_id);
    $stmt_product->execute();
    $result_product = $stmt_product->get_result();

    if ($result_product->num_rows === 1) {
        $product = $result_product->fetch_assoc();
    } else {
        $error_msg = "No se encontró el plato.";
    }
    $stmt_product->close();

    $cat_sql = "SELECT * FROM tbl_categories ORDER BY order_index ASC";
    $cat_result = $conn->query($cat_sql);
    if ($cat_result && $cat_result->num_rows > 0) {
        while($row = $cat_result->fetch_assoc()) {
            $categories[] = $row;
        }
    }

} else {
    if ($_SERVER["REQUEST_METHOD"] != "POST") {
        header('Location: admin_products.php?error=noid');
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Plato - Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        
        <a href="admin_products.php" class="back-link">&larr; Volver a Platos</a>
        
        <h1>Editar Plato</h1>
        <p>Modifica los detalles del plato seleccionado.</p>

        <div class="form-container" style="max-width: 600px; margin: 20px auto;">
            
            <?php if ($product): ?>
                
                <h3>Editando: <?php echo htmlspecialchars($product['name']); ?></h3>
                
                <form action="admin_edit_product.php" method="POST" enctype="multipart/form-data">
                    
                    <input type="hidden" name="product_id" value="<?php echo $product['product_id']; ?>">
                    <input type="hidden" name="old_image_path" value="<?php echo htmlspecialchars($product['image_url']); ?>">

                    <?php if (!empty($error_msg)): ?>
                        <div class="message error"><?php echo $error_msg; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="category_id">Categoría (*)</label>
                        <select id="category_id" name="category_id" required>
                            <option value="">-- Seleccione --</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['category_id']; ?>" 
                                    <?php if ($category['category_id'] == $product['category_id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="input-group">
                        <label for="product_name">Nombre del Plato (*)</label>
                        <input type="text" id="product_name" name="product_name" 
                               value="<?php echo htmlspecialchars($product['name']); ?>" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="product_desc">Descripción (*)</label>
                        <textarea id="product_desc" name="product_desc" rows="4" required><?php echo htmlspecialchars($product['description']); ?></textarea>
                    </div>
                    
                    <div class="input-group">
                        <label for="price_usd">Precio (USD) (*)</label>
                        <input type="number" id="price_usd" name="price_usd" step="0.01" min="0" 
                               value="<?php echo $product['price_usd']; ?>" required>
                    </div>

                    <div class="input-group">
                        <label>Imagen Actual</label>
                        <div>
                            <?php if (!empty($product['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="img" class="table-image">
                            <?php else: ?>
                                <span class="no-image">No hay imagen</span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="input-group">
                        <label for="product_image">Subir Nueva Imagen (Opcional)</label>
                        <input type="file" id="product_image" name="product_image" accept="image/jpeg, image/png">
                    </div>
                    
                    <button type="submit" name="update_product" class="submit-button">Guardar Cambios</button>
                </form>
            
            <?php else: ?>
                <div class="message error"><?php echo $error_msg; ?></div>
            <?php endif; ?>

        </div>

    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>