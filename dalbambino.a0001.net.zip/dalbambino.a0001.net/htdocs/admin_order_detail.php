<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
require_once 'api/db_connect.php';

$order_id = (int)$_GET['id'];
$order = null;
$order_items = [];
$error_msg = '';
$success_msg = '';

// --- 3. [LÓGICA PARA ACTUALIZAR ESTADO] ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status'])) {
    
    $new_status = $_POST['new_status'];
    $order_id_to_update = (int)$_POST['order_id'];

    $allowed_statuses = ['pending', 'completed', 'cancelled'];
    if (in_array($new_status, $allowed_statuses) && $order_id_to_update == $order_id) {
        
        $sql_update = "UPDATE tbl_orders SET status = ? WHERE order_id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("si", $new_status, $order_id_to_update);

        if ($stmt_update->execute()) {
            $success_msg = "¡Estado del pedido actualizado con éxito!";
        } else {
            $error_msg = "Error al actualizar el estado: " . $conn->error;
        }
        $stmt_update->close();
    } else {
        $error_msg = "Error: Estado no válido o ID de pedido incorrecto.";
    }
}

// --- 4. [LÓGICA PARA LEER EL PEDIDO] ---
$sql_order = "SELECT * FROM tbl_orders WHERE order_id = ?";
$stmt_order = $conn->prepare($sql_order);
$stmt_order->bind_param("i", $order_id);
$stmt_order->execute();
$result_order = $stmt_order->get_result();
if ($result_order->num_rows === 1) {
    $order = $result_order->fetch_assoc();
} else {
    header('Location: admin_orders.php?error=notfound');
    exit();
}
$stmt_order->close();

$sql_items = "SELECT oi.*, p.name AS product_name 
              FROM tbl_order_items oi
              JOIN tbl_products p ON oi.product_id = p.product_id
              WHERE oi.order_id = ?";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $order_id);
$stmt_items->execute();
$result_items = $stmt_items->get_result();
if ($result_items->num_rows > 0) {
    while($row = $result_items->fetch_assoc()) {
        $order_items[] = $row;
    }
}
$stmt_items->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Pedido #<?php echo $order_id; ?> - Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        
        <div class="page-header-actions">
            <a href="admin_orders.php" class="back-link">&larr; Volver a Todos los Pedidos</a>
            
            <a href="admin_print_order.php?id=<?php echo $order['order_id']; ?>" 
               target="_blank" 
               class="print-button">
               <i data-feather="printer"></i> Imprimir Comanda
            </a>
            </div>
        
        <h1>Detalle del Pedido #<?php echo $order_id; ?></h1>
        
        <div class="order-detail-grid">
            
            <div class="list-container">
                <h3>Platos Pedidos</h3>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Plato</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Notas del Cliente</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($order_items as $item): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($item['product_name']); ?></strong></td>
                                <td><?php echo $item['quantity']; ?></td>
                                <td>$<?php echo number_format($item['price_per_item'], 2); ?></td>
                                <td><i><?php echo htmlspecialchars($item['notes']) ?: '---'; ?></i></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="form-container">
                <h3>Información del Cliente</h3>
                <div class="info-group">
                    <label>Cliente:</label>
                    <span><?php echo htmlspecialchars($order['customer_name']); ?></span>
                </div>
                <div class="info-group">
                    <label>Teléfono (WhatsApp):</label>
                    <span><?php echo htmlspecialchars($order['customer_phone']); ?></span>
                </div>
                <div class="info-group">
                    <label>Tipo de Pedido:</label>
                    <span class="status-badge type-<?php echo htmlspecialchars($order['order_type']); ?>">
                        <?php echo htmlspecialchars($order['order_type']); ?>
                    </span>
                </div>
                <div class="info-group">
                    <label><?php echo ($order['order_type'] == 'room') ? 'Habitación:' : 'Dirección:'; ?></label>
                    <span><?php echo nl2br(htmlspecialchars($order['customer_address'])); ?></span>
                </div>
                <hr class="info-divider">
                <h3>Total del Pedido</h3>
                <div class="info-group total">
                    <label>Total Pagado (USD):</label>
                    <span>$<?php echo number_format($order['total_usd'], 2); ?></span>
                </div>
                <hr class="info-divider">
                <h3>Actualizar Estado</h3>
                <?php if (!empty($success_msg)): ?>
                    <div class="message success"><?php echo $success_msg; ?></div>
                <?php endif; ?>
                <?php if (!empty($error_msg)): ?>
                    <div class="message error"><?php echo $error_msg; ?></div>
                <?php endif; ?>
                <form class="status-form" action="admin_order_detail.php?id=<?php echo $order['order_id']; ?>" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $order['order_id']; ?>">
                    <div class="input-group">
                        <select name="new_status">
                            <option value="pending" <?php if ($order['status'] == 'pending') echo 'selected'; ?>>Pendiente</option>
                            <option value="completed" <?php if ($order['status'] == 'completed') echo 'selected'; ?>>Completado</option>
                            <option value="cancelled" <?php if ($order['status'] == 'cancelled') echo 'selected'; ?>>Cancelado</option>
                        </select>
                    </div>
                    <button type="submit" name="update_status" class="submit-button">Actualizar</button>
                </form>
            </div>
        </div>
    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>