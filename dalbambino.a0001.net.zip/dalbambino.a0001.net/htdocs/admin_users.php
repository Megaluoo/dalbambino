<?php
// --- 1. Iniciar la Sesión y Seguridad ---
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}
if ($_SESSION['role'] !== 'superadmin') {
    header('Location: admin_dashboard.php?error=unauthorized');
    exit();
}

// --- 2. Incluir la conexión ---
require_once 'api/db_connect.php';

$error_msg = '';
$success_msg = '';

// --- LÓGICA DE MENSAJES DE ESTADO (NUEVO) ---
if (isset($_GET['status']) && $_GET['status'] == 'deleted') {
    $success_msg = "¡Usuario borrado con éxito!";
}
if (isset($_GET['error'])) {
    if ($_GET['error'] == 'noid') {
        $error_msg = "No se seleccionó ningún usuario.";
    }
    if ($_GET['error'] == 'cannotdeleteprimary') {
        $error_msg = "Error: No se puede eliminar al superadministrador principal (ID 1).";
    }
    if ($_GET['error'] == 'deletefailed') {
        $error_msg = "Error al borrar el usuario.";
    }
}
// --- FIN DE LÓGICA DE MENSAJES ---


// --- 3. [LÓGICA PARA AÑADIR USUARIO] ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    
    $username = trim($_POST['username']);
    $plain_password = trim($_POST['password']);
    $role = $_POST['role'];

    if (!empty($username) && !empty($plain_password) && !empty($role)) {
        
        $password_hash = password_hash($plain_password, PASSWORD_DEFAULT);

        if ($password_hash === false) {
            $error_msg = "Error: Falló la función de hash.";
        } else {
            $sql = "INSERT INTO tbl_users (username, password_hash, role) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $username, $password_hash, $role);

            if ($stmt->execute()) {
                $success_msg = "¡Usuario '" . htmlspecialchars($username) . "' añadido con éxito!";
            } else {
                if ($conn->errno == 1062) {
                    $error_msg = "Error: El nombre de usuario '" . htmlspecialchars($username) . "' ya existe.";
                } else {
                    $error_msg = "Error al añadir el usuario: " . $conn->error;
                }
            }
            $stmt->close();
        }
    } else {
        $error_msg = "Todos los campos son obligatorios.";
    }
}

// --- 4. [LÓGICA PARA LEER USUARIOS] ---
$users = [];
$sql_select = "SELECT user_id, username, role FROM tbl_users";
$result = $conn->query($sql_select);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Usuarios - Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?> (Superadmin)</strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        
        <a href="admin_dashboard.php" class="back-link">&larr; Volver al Panel de Control</a>
        
        <h1>Gestionar Usuarios</h1>
        <p>Añade o elimina cuentas de administrador para tu cliente.</p>

        <div class="content-grid">

            <div class="form-container">
                <h3>Añadir Nuevo Usuario</h3>
                
                <form action="admin_users.php" method="POST">
                    
                    <?php if (!empty($success_msg)): ?>
                        <div class="message success"><?php echo $success_msg; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($error_msg)): ?>
                        <div class="message error"><?php echo $error_msg; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="username">Nombre de Usuario (*)</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="password">Contraseña (*)</label>
                        <input type="text" id="password" name="password" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="role">Rol (*)</label>
                        <select id="role" name="role" required>
                            <option value="admin">Administrador (Cliente)</option>
                            <option value="superadmin">Super Administrador (Tú)</option>
                        </select>
                    </div>
                    
                    <button type="submit" name="add_user" class="submit-button">Crear Usuario</button>
                </form>
            </div>

            <div class="list-container">
                <h3>Usuarios Actuales</h3>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Usuario</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="4">No hay usuarios.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['user_id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                                    <td>
                                        <span class="status-badge <?php echo ($user['role'] == 'superadmin') ? 'superadmin-card' : 'type-delivery'; ?>">
                                            <?php echo htmlspecialchars($user['role']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['user_id'] != 1): ?>
                                            <a href="api/delete_user.php?id=<?php echo $user['user_id']; ?>" 
                                               class="action-btn delete"
                                               onclick="return confirm('¿Estás seguro de que quieres borrar al usuario \'<?php echo htmlspecialchars($user['username']); ?>\'?');">
                                               Borrar
                                            </a>
                                        <?php else: ?>
                                            <span>(Principal)</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>

    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>