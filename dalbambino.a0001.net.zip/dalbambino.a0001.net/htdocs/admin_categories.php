<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html?error=pleaselogin');
    exit();
}

require_once 'api/db_connect.php';

$error_msg = '';
$success_msg = '';

// --- LÓGICA DE MENSAJES DE ESTADO (ACTUALIZADO) ---
if (isset($_GET['status'])) {
    if ($_GET['status'] == 'deleted') {
        $success_msg = "¡Categoría borrada con éxito!";
    }
    if ($_GET['status'] == 'updated') {
        $success_msg = "¡Categoría actualizada con éxito!";
    }
}
if (isset($_GET['error'])) {
    if ($_GET['error'] == 'deletefailed') {
        $error_msg = "Error al borrar la categoría.";
    }
    if ($_GET['error'] == 'noid') {
        $error_msg = "No se seleccionó ninguna categoría.";
    }
}
// --- FIN DE LÓGICA DE MENSAJES ---


// --- [LÓGICA PARA AÑADIR] ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    
    $category_name = trim($_POST['category_name']);
    $category_desc = trim($_POST['category_desc']);
    $order_index = (int)$_POST['order_index'];

    if (!empty($category_name)) {
        $sql = "INSERT INTO tbl_categories (name, description, order_index) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $category_name, $category_desc, $order_index);

        if ($stmt->execute()) {
            $success_msg = "¡Categoría '" . htmlspecialchars($category_name) . "' añadida con éxito!";
        } else {
            $error_msg = "Error al añadir la categoría: " . $conn->error;
        }
        $stmt->close();
    } else {
        $error_msg = "El nombre de la categoría no puede estar vacío.";
    }
}

// --- [LÓGICA PARA LEER] ---
$categories = [];
$sql_select = "SELECT * FROM tbl_categories ORDER BY order_index ASC";
$result = $conn->query($sql_select);

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Categorías - Admin</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="css/admin-style.css">
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body>

    <header class="admin-header">
        <div class="header-container">
            <div class="brand-logo">
                Dal Bambino <span>Portal Admin</span>
            </div>
            <div class="user-info">
                <span>Hola, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></span>
                <a href="api/logout.php" class="logout-button">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <main class="admin-container">
        
        <a href="admin_dashboard.php" class="back-link">&larr; Volver al Panel de Control</a>
        
        <h1>Gestionar Categorías</h1>
        <p>Añade, edita o elimina las secciones de tu menú (ej: Entradas, Pastas, Postres).</p>

        <div class="content-grid">

            <div class="form-container">
                <h3>Añadir Nueva Categoría</h3>
                
                <form action="admin_categories.php" method="POST">
                    
                    <?php if (!empty($success_msg)): ?>
                        <div class="message success"><?php echo $success_msg; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($error_msg)): ?>
                        <div class="message error"><?php echo $error_msg; ?></div>
                    <?php endif; ?>

                    <div class="input-group">
                        <label for="category_name">Nombre de la Categoría (*)</label>
                        <input type="text" id="category_name" name="category_name" required>
                    </div>
                    
                    <div class="input-group">
                        <label for="category_desc">Descripción (Opcional)</label>
                        <textarea id="category_desc" name="category_desc" rows="3"></textarea>
                    </div>
                    
                    <div class="input-group">
                        <label for="order_index">Orden (ej: 1, 2, 3...)</label>
                        <input type="number" id="order_index" name="order_index" value="0">
                    </div>
                    
                    <button type="submit" name="add_category" class="submit-button">Añadir Categoría</button>
                </form>
            </div>

            <div class="list-container">
                <h3>Categorías Actuales</h3>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Orden</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($categories)): ?>
                            <tr>
                                <td colspan="4">Aún no has añadido ninguna categoría.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($categories as $category): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($category['order_index']); ?></td>
                                    <td><strong><?php echo htmlspecialchars($category['name']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($category['description']); ?></td>
                                    <td>
                                        <a href="admin_edit_category.php?id=<?php echo $category['category_id']; ?>" 
                                           class="action-btn edit">
                                           Editar
                                        </a>
                                        <a href="api/delete_category.php?id=<?php echo $category['category_id']; ?>" 
                                           class="action-btn delete" 
                                           onclick="return confirm('¿Estás seguro de que quieres borrar la categoría \'<?php echo htmlspecialchars($category['name']); ?>\'?');">
                                           Borrar
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>

    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>